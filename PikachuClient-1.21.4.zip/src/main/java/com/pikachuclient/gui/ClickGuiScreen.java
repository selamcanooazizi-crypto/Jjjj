package com.pikachuclient.gui;

import com.pikachuclient.PikachuClient;
import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.setting.BooleanSetting;
import com.pikachuclient.module.setting.NumberSetting;
import com.pikachuclient.module.setting.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ClickGuiScreen extends Screen {
    private static final int COL_W = 120;
    private static final int ROW_H = 14;
    private static final int SET_H = 12;

    private record Hit(int x, int y, int w, int h, Runnable left, Runnable right) {
    }

    private final List<Hit> hits = new ArrayList<>();
    private Module expanded;

    public ClickGuiScreen() {
        super(Text.literal(""));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        hits.clear();

        int x = 10;
        for (Category category : Category.values()) {
            List<Module> list = new ArrayList<>();
            for (Module m : PikachuClient.modules.all()) {
                if (m.category == category) {
                    list.add(m);
                }
            }
            if (list.isEmpty()) {
                continue;
            }

            int y = 14;
            context.fill(x, y, x + COL_W, y + ROW_H, 0xDD1E1E2E);
            context.drawText(textRenderer, category.label, x + 4, y + 3, 0xFFFFD84D, false);
            y += ROW_H;

            for (Module m : list) {
                final Module module = m;
                boolean on = m.isEnabled();
                context.fill(x, y, x + COL_W, y + ROW_H, on ? 0xCC2E7D32 : 0xAA000000);
                context.drawText(textRenderer, m.name, x + 4, y + 3, 0xFFFFFFFF, false);
                if (!m.settings.isEmpty()) {
                    context.drawText(textRenderer, expanded == m ? "-" : "+", x + COL_W - 10, y + 3, 0xFFAAAAAA, false);
                }
                hits.add(new Hit(x, y, COL_W, ROW_H, module::toggle,
                        () -> expanded = (expanded == module ? null : module)));
                y += ROW_H;

                if (expanded == m) {
                    for (Setting<?> s : m.settings) {
                        context.fill(x, y, x + COL_W, y + SET_H, 0xAA101018);
                        if (s instanceof BooleanSetting b) {
                            context.drawText(textRenderer, b.name + ": " + (b.get() ? "On" : "Off"),
                                    x + 8, y + 2, b.get() ? 0xFF7CFC7C : 0xFFCCCCCC, false);
                            hits.add(new Hit(x, y, COL_W, SET_H, b::toggle, b::toggle));
                        } else if (s instanceof NumberSetting n) {
                            context.drawText(textRenderer, "< " + n.name + ": " + n.display() + " >",
                                    x + 8, y + 2, 0xFFCCCCCC, false);
                            hits.add(new Hit(x, y, COL_W / 2, SET_H, n::decrease, n::decrease));
                            hits.add(new Hit(x + COL_W / 2, y, COL_W / 2, SET_H, n::increase, n::increase));
                        }
                        y += SET_H;
                    }
                }
            }
            x += COL_W + 6;
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (mouseX >= h.x() && mouseX < h.x() + h.w() && mouseY >= h.y() && mouseY < h.y() + h.h()) {
                if (button == 0) {
                    h.left().run();
                } else if (button == 1) {
                    h.right().run();
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        PikachuClient.modules.save();
    }
}
