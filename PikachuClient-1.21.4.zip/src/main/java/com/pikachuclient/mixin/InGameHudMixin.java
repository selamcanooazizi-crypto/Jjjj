package com.pikachuclient.mixin;

import com.pikachuclient.PikachuClient;
import com.pikachuclient.module.misc.ScoreboardToggleModule;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {
    @Inject(method = "renderScoreboardSidebar", at = @At("HEAD"), cancellable = true)
    private void pikachu$hideScoreboard(CallbackInfo ci) {
        if (PikachuClient.modules == null) {
            return;
        }
        ScoreboardToggleModule m = PikachuClient.modules.get(ScoreboardToggleModule.class);
        if (m != null && m.isEnabled()) {
            ci.cancel();
        }
    }
}
