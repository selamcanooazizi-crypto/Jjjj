package com.pikachuclient.mixin;

import com.pikachuclient.PikachuClient;
import com.pikachuclient.module.render.NoHurtCamModule;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
    private void pikachu$noHurtCam(CallbackInfo ci) {
        if (PikachuClient.modules == null) {
            return;
        }
        NoHurtCamModule m = PikachuClient.modules.get(NoHurtCamModule.class);
        if (m != null && m.isEnabled()) {
            ci.cancel();
        }
    }
}
