package com.pikachuclient.mixin;

import com.pikachuclient.PikachuClient;
import com.pikachuclient.module.render.ViewModelModule;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
    @Unique
    private boolean pikachu$pushed;

    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
    private void pikachu$viewModelHead(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                                       float swingProgress, ItemStack item, float equipProgress,
                                       MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                                       CallbackInfo ci) {
        pikachu$pushed = false;
        if (PikachuClient.modules == null) {
            return;
        }
        ViewModelModule m = PikachuClient.modules.get(ViewModelModule.class);
        if (m != null && m.isEnabled()) {
            matrices.push();
            matrices.translate(m.x.f(), m.y.f(), m.z.f());
            float s = m.scale.f();
            matrices.scale(s, s, s);
            pikachu$pushed = true;
        }
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"))
    private void pikachu$viewModelReturn(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                                         float swingProgress, ItemStack item, float equipProgress,
                                         MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                                         CallbackInfo ci) {
        if (pikachu$pushed) {
            matrices.pop();
            pikachu$pushed = false;
        }
    }
}
