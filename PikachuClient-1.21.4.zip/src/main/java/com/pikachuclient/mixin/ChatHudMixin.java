package com.pikachuclient.mixin;

import com.pikachuclient.PikachuClient;
import com.pikachuclient.module.misc.ChatToggleModule;
import net.minecraft.client.gui.hud.ChatHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChatHud.class)
public class ChatHudMixin {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void pikachu$hideChat(CallbackInfo ci) {
        if (PikachuClient.modules == null) {
            return;
        }
        ChatToggleModule m = PikachuClient.modules.get(ChatToggleModule.class);
        if (m != null && m.isEnabled()) {
            ci.cancel();
        }
    }
}
