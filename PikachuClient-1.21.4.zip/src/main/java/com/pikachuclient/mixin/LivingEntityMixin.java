package com.pikachuclient.mixin;

import com.pikachuclient.PikachuClient;
import com.pikachuclient.module.misc.SwingSpeedModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public class LivingEntityMixin {
    @Inject(method = "getHandSwingDuration", at = @At("RETURN"), cancellable = true)
    private void pikachu$swingSpeed(CallbackInfoReturnable<Integer> cir) {
        if (PikachuClient.modules == null) {
            return;
        }
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || (Object) this != mc.player) {
            return;
        }
        SwingSpeedModule m = PikachuClient.modules.get(SwingSpeedModule.class);
        if (m != null && m.isEnabled()) {
            cir.setReturnValue(m.duration.i());
        }
    }
}
