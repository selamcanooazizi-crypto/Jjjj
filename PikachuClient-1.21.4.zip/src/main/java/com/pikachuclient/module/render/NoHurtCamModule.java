package com.pikachuclient.module.render;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;

public class NoHurtCamModule extends Module {
    public NoHurtCamModule() {
        super("No Hurt Cam", "Removes the camera shake when you take damage.", Category.RENDER);
    }
}
