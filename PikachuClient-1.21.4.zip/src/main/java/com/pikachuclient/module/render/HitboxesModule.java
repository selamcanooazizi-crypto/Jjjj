package com.pikachuclient.module.render;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import net.minecraft.client.MinecraftClient;

public class HitboxesModule extends Module {
    public HitboxesModule() {
        super("Hitboxes", "Shows entity hitboxes.", Category.RENDER);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        mc.getEntityRenderDispatcher().setRenderHitboxes(true);
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null) {
            mc.getEntityRenderDispatcher().setRenderHitboxes(false);
        }
    }
}
