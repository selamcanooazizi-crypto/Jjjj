package com.pikachuclient.module;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.pikachuclient.module.hud.*;
import com.pikachuclient.module.misc.*;
import com.pikachuclient.module.render.*;
import com.pikachuclient.module.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        modules.add(new FpsModule());
        modules.add(new CpsModule());
        modules.add(new CoordsModule());
        modules.add(new PingModule());
        modules.add(new ClockModule());
        modules.add(new KeystrokesModule());

        modules.add(new FullbrightModule());
        modules.add(new NoHurtCamModule());
        modules.add(new LowFireModule());
        modules.add(new ViewModelModule());
        modules.add(new HitboxesModule());

        modules.add(new SprintModule());

        modules.add(new SwingSpeedModule());

        modules.add(new TimeChangerModule());

        modules.add(new ChatToggleModule());
        modules.add(new ScoreboardToggleModule());
    }

    public List<Module> all() {
        return modules;
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> type) {
        for (Module m : modules) {
            if (type.isInstance(m)) {
                return (T) m;
            }
        }
        return null;
    }

    public void tick(MinecraftClient mc) {
        for (Module m : modules) {
            if (m.isEnabled()) {
                try {
                    m.onTick(mc);
                } catch (Throwable ignored) {
                }
            }
        }
    }

    public void renderHud(DrawContext context, MinecraftClient mc) {
        int y = 4;
        for (Module m : modules) {
            if (m.isEnabled()) {
                try {
                    y = m.renderHud(context, mc, y);
                } catch (Throwable ignored) {
                }
            }
        }
    }

    private Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("pikachuclient.json");
    }

    public void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : modules) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.isEnabled());
                JsonObject s = new JsonObject();
                for (Setting<?> setting : m.settings) {
                    s.add(setting.name, setting.toJson());
                }
                o.add("settings", s);
                root.add(m.name, o);
            }
            try (Writer w = Files.newBufferedWriter(file())) {
                GSON.toJson(root, w);
            }
        } catch (Throwable ignored) {
        }
    }

    public void load() {
        try {
            if (!Files.exists(file())) {
                return;
            }
            JsonObject root;
            try (Reader r = Files.newBufferedReader(file())) {
                root = GSON.fromJson(r, JsonObject.class);
            }
            if (root == null) {
                return;
            }
            for (Module m : modules) {
                if (!root.has(m.name) || !root.get(m.name).isJsonObject()) {
                    continue;
                }
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("settings") && o.get("settings").isJsonObject()) {
                    JsonObject s = o.getAsJsonObject("settings");
                    for (Setting<?> setting : m.settings) {
                        if (s.has(setting.name)) {
                            setting.fromJson(s.get(setting.name));
                        }
                    }
                }
                if (o.has("enabled")) {
                    m.setEnabled(o.get("enabled").getAsBoolean());
                }
            }
        } catch (Throwable ignored) {
        }
    }
}
