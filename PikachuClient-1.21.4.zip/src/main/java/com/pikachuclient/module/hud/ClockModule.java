package com.pikachuclient.module.hud;

import net.minecraft.client.MinecraftClient;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class ClockModule extends TextHudModule {
    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("HH:mm");

    public ClockModule() {
        super("Clock", "Shows the real time.");
    }

    @Override
    protected String text(MinecraftClient mc) {
        return LocalTime.now().format(FORMAT);
    }
}
