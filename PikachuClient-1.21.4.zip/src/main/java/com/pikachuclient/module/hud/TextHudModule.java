package com.pikachuclient.module.hud;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public abstract class TextHudModule extends Module {
    protected TextHudModule(String name, String description) {
        super(name, description, Category.HUD);
    }

    protected abstract String text(MinecraftClient mc);

    @Override
    public int renderHud(DrawContext context, MinecraftClient mc, int y) {
        String t = text(mc);
        if (t == null) {
            return y;
        }
        context.drawText(mc.textRenderer, t, 4, y, 0xFFFFFFFF, true);
        return y + 11;
    }
}
