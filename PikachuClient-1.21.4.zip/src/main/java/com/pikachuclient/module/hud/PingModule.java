package com.pikachuclient.module.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;

public class PingModule extends TextHudModule {
    public PingModule() {
        super("Ping", "Shows your ping.");
    }

    @Override
    protected String text(MinecraftClient mc) {
        if (mc.player == null || mc.getNetworkHandler() == null) {
            return null;
        }
        PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        if (entry == null) {
            return "Ping: -";
        }
        return "Ping: " + entry.getLatency() + " ms";
    }
}
