package com.pikachuclient.module.hud;

import net.minecraft.client.MinecraftClient;

public class FpsModule extends TextHudModule {
    public FpsModule() {
        super("FPS", "Shows your frames per second.");
    }

    @Override
    protected String text(MinecraftClient mc) {
        return "FPS: " + mc.getCurrentFps();
    }
}
