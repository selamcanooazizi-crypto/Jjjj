package com.pikachuclient.module.misc;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;

public class ChatToggleModule extends Module {
    public ChatToggleModule() {
        super("Hide Chat", "Hides the chat while enabled.", Category.MISC);
    }
}
