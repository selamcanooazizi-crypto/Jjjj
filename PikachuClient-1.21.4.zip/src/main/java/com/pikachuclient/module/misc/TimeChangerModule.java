package com.pikachuclient.module.misc;

import com.pikachuclient.module.Category;
import com.pikachuclient.module.Module;
import com.pikachuclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;

public class TimeChangerModule extends Module {
    public final NumberSetting time = add(new NumberSetting("Time", 6000, 0, 24000, 500));

    public TimeChangerModule() {
        super("Time Changer", "Changes the time of day (client side only).", Category.WORLD);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.world != null) {
            mc.world.setTimeOfDay((long) time.i());
        }
    }
}
